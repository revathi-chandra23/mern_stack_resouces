### Role Based Access Control.

Role Bases acccess Control (RBAC) is a security paradigm where users are granted access to resourcess on their role in the company.
RBAC if implemented correctly, it can be an effective wway to enforcing the principle of least privilege.

## the basics

most RBAC are based on the application on three principle. h

1. Role assignment : A subject can exercise a permission only if the subject has selected or been assigned a role.

2. Role authorization: A subject's active role must be authorized. that is I can't just assign myself to a role. I need authorization.

3. Permission authorization: A subject can exercise a permission only if the permission is authorized for the subject's active role.
   With rules 1 and 2 this rule ensure that users can only exercise permissions for which they are authorized.

## the benefies of RBAC.

1. maximum efficieny.
2. protect dta
3. reduces admin and IT work.
4. simplifies audits.
5. reduces risk of breaches.

## implementing Role based access control.

1. Define the resource an service you provide to users( eg: email, file share , cloud apps)

2. create a mapping of roles to resource from step 1 such that each function access resources needed to complete their job.

3. create security group that represent each role.

4. assign users to define roles by adding them to relevent role based group.

5. apply group to access control list on the resources.
