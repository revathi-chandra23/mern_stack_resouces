## sending emails

SMTP: simple mail transfer protocol
It is a communication protocol used to send and receive email messages between email services.

SMTP is a simpe, text based protocol that enables the transfer of email message between different email clients and service.

some important points in SMTP:

1. it is client-server protocol, which means that one computer communicated with another computer in order to send and receive email message.

2. it is responsible for the transfer of email message between different servers.
   it is not responsible for the storage or retrieval of email messages on individula computer.

3. It uses port 25 to communicate between email servers, although some email providers use other ports for security response.

4. It is a simple protocol that uses simple text commands to initiate and complete email transer.

5. It is not responsible for detecting or filtering spam or other unwanted message.

## NodeMailer

it is a module for Nodejs that enable you to send emails using JS.
It is simple and flexible.
It supports SMTP, sendingmail, AMAZON SES.

features:
sending attachment
plain text
html email
customizable email templates
Oauth authentication
