//Define roles and permission.

const roles = {
  admin: {
    permission: ["read", "write", "delete"],
  },
  user: {
    permission: ["read"],
  },
};

//Define middleware function to check user roles and permission.

function checkRole(role) {
  return function (req, res, next) {
    if (
      req.user &&
      roles[req.user.role] &&
      roles[req.user.role].permission.includes(req.method.toLowerCase())
    ) {
      return next();
    } else {
      return res.status(403).send("forbidden");
    }
  };
}

//applying middleware to routes

app.get("/admin", checkRole("admin"), function (req, res) {
  res.send("admin page");
});

app.get("/user", checkRole("user"), function (req, res) {
  res.send("user page");
});
