redux toolkit

- redux (core library, state management)
- immer (allows to mutate state)
- redux-thunk (handle async actions)
- reselect (simplifies reducer function)
