import { StarIcon } from "@chakra-ui/icons";
import { Box } from "@chakra-ui/react";
import React from "react";

const Stars = ({ rating, reviewCount }) => {
  return (
    <Box display="flex" mt="2" alignItems="center">
      {new Array(5).fill("").map((_, i) => (
        <StarIcon key={i} color={i < rating ? "teal.500" : "gray.300"} />
      ))}
      <Box as="span" ml="2" color="gray.600" fontSize="sm">
        {reviewCount} reviews
      </Box>
    </Box>
  );
};

export default Stars;
