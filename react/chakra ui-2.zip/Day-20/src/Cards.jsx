import { div } from "framer-motion/client";
import React from "react";

const Cards = ({ children, title, style }) => {
  return (
    <div
      style={{
        border: "1px solid black",
        padding: "16px",
        borderRadius: "8px",
        ...style,
        //copying
      }}
    >
      {title && <h2>{title}</h2>}
      <div>{children}</div>
    </div>
  );
};

export default Cards;
