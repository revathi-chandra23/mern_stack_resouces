import { applyMiddleware, combineReducers, legacy_createStore } from "redux";
import { reducerFunction as CounterReducer } from "./Counter/reducer";
import { reducerFunction as TodoReducer } from "./Todo/reducer";
import { reducer as AuthReducer } from "./authentication/reducer";
import { composeWithDevTools } from "@redux-devtools/extension";
const rootReducer = combineReducers({
  CounterReducer,
  TodoReducer,
  AuthReducer,
});

export const store = legacy_createStore(
  rootReducer,
  composeWithDevTools(applyMiddleware())
);

// useReducer(function, initialValue)
