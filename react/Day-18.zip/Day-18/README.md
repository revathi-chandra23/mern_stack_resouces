### phase 1

You are required to build a simple counter component in React using the **`useReducer`** hook. The counter should be able to increment and decrement a count value using buttons.

Use the **`useReducer`** hook and the `reducer` function provided to manage the state of the count value. The initial count value should be `0`.

Your solution should have the following features:

- When the user clicks the increment button, the count value in the state should be incremented.
- When the user clicks the decrement button, the count value in the state should be decremented.

Implement the **`Counter`** component in the provided code block using the **`useReducer`** hook and the `reducer` function. The component should display the current count value and have buttons to increment and decrement it.

### phase -2

Your task is to create a simple Todo application using React and the **`useReducer`** hook. The Todo application should allow the user to add new tasks, delete existing tasks, and mark tasks as completed.

You will need to create four components for this application:

1. **`Todo`**: The main component that will manage the state of the application using **`useReducer`** hook. It will render the **`AddTodo`** and **`TodoItem`** components.
2. **`AddTodo`**: A component that will allow the user to add new tasks to the Todo list.
3. **`TodoItem`**: A component that will render a single Todo item. It will display the task title and its completion status. It will also allow the user to delete the task and mark it as completed.
4. **`reducer`**: A function that will handle the state changes for the Todo application.

The **`Todo`** component should use the **`useReducer`** hook to manage the state of the Todo list. The initial state should be an array of three pre-defined tasks. Each task should have an **`id`**, a **`title`**, and a **`status`** property. The **`status`** property should be **`false`** for tasks that are not completed and **`true`** for tasks that are completed.

The **`AddTodo`** component should allow the user to input a task title and add it to the Todo list when the "ADD" button is clicked. Each new task should have a unique **`id`** and a **`status`** property set to **`false`**.

The **`TodoItem`** component should render a single Todo item. It should display the task title and its completion status. If the task is completed, the status should be displayed as "DONE". If the task is not completed, the status should be displayed as "NOT DONE". It should also provide buttons to delete the task and mark it as completed.

The **`reducer`** function should handle three types of actions: **`ADD_TASK`**, **`DELETE_TASK`**, and **`UPDATE_TASK`**. The **`ADD_TASK`** action should add a new task to the Todo list. The **`DELETE_TASK`** action should remove a task from the Todo list. The **`UPDATE_TASK`** action should update the completion status of a task.

You should test your Todo application to make sure it works as expected.

## phase -3

- Class Phase 3
  You are required to build a form component in React using the **`useReducer`** hook. The form should contain the following fields:
  - Username: a text input field where the user can enter their username.
  - Age: a number field with buttons to increment and decrement the value.
  - Country: a dropdown to select the user's country from a list of options.
  - Update Details: a button that logs the form values to the console and resets the form to its initial state.
  Use the **`useReducer`** hook and the **`reducer`** function provided to manage the state of the form. The initial state should have empty values for username and country, and a default age of 18.
  Your solution should have the following features:
  - When the user types in the username field, the state should be updated with the new value.
  - When the user clicks the increment or decrement buttons, the age value in the state should be updated accordingly.
  - When the user selects a country from the dropdown, the country value in the state should be updated.
  - When the user clicks the update details button, the current state values should be logged to the console and the form should be reset to its initial state.
  Implement the **`Form`** component in the provided code block using the **`useReducer`** hook and the **`reducer`** function.
