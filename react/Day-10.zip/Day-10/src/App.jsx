import React, { useContext } from "react";
import Navbar from "./component/Navbar";
import { ThemeContext } from "./context/ThemeContextProvider";

const App = () => {
  //3. to access data from context.
  const { theme, ToggleTheme } = useContext(ThemeContext);

  return (
    <div
      className="App"
      style={{
        background: theme === "dark" ? "black" : "white",
        color: theme === "dark" ? "white" : "black",
        padding: "10px",
      }}
    >
      <Navbar />
      <button onClick={ToggleTheme}>Toggle theme</button>
    </div>
  );
};

export default App;
