import { createContext, useState } from "react";
// 1. create context
export const ThemeContext = createContext();

// 2. provider
export const ThemeContextProvider = (props) => {
  const [theme, setTheme] = useState("dark");

  const ToggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <ThemeContext.Provider value={{ theme, ToggleTheme }}>
      {props.children}
      {/* <App/> */}
    </ThemeContext.Provider>
  );
};
