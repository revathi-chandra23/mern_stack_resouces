import React, { useContext } from "react";
import { AppContext } from "../context/AppContextProvider";

const Navbar = () => {
  const { isAuth, login, logout } = useContext(AppContext);
  return (
    <div
      style={{ display: "flex", justifyContent: "space-between", gap: "10px" }}
    >
      <h5>Is User Authenticated : {isAuth ? "Yes" : "No"}</h5>
      {!isAuth && <button onClick={login}>login</button>}
      {isAuth && <button onClick={logout}>logout</button>}
    </div>
  );
};

export default Navbar;
