//node
Deno

Node server ->
GET/ POST
//form a file
//from a DB
//from an other API
res.send(Post)

express - library

Node --> v8 engine + inbuilt modules (http)

Event loop : stack --> browser engine --> (micro task queue + task queue ) --> stack

- watch what the heck is event loop;
- Read the difference betweenn event loop on browser vs event loop on node

Timers

setTimeout
setInterval

// fetch ---> 2sec
// setTimeout --->2 sec

// promise vs timer ---> promise takes more priority
// queue---> micro task queue / task queue

// promise --> 5 sec
// setTimeout ---> 2 sec

// setImmediate ---> similar to setTimeout with 0ms.

procces.nextTick --->this takes more priority then setImmediate , both inside / outside the I/O operation.

//micro task queue ---> promise , process.nextTick.

task queue --> setTimeout, setInterval, setImmediate
