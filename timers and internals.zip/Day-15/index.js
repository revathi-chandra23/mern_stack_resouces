// console.log("a");

// setTimeout(() => {
//   console.log("h");
// }, 0);

// setTimeout(() => {
//   console.log("c");
// }, 2000);

// setTimeout(() => {
//   console.log("b");
// }, 1000);

// console.log("x");

// setTimeout(() => {
//   console.log("b");
// }, 0);

// setImmediate(() => {
//   console.log("m");
// });

// read , write , network calls
// IO operation -->  setImmediate will always take more priority thane setTimeout(with 0ms)

const fs = require("fs");
fs.readFile("./lecture.txt", "utf-8", (err, data) => {
  setTimeout(() => {
    console.log("b");
  }, 0);

  setImmediate(() => {
    console.log("m");
  });

  process.nextTick(() => {
    console.log("z");
  });
});
