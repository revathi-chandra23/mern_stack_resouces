const express = require("express");

const { studentRouter } = require("./routes/student.router");
const { teacherRouter } = require("./routes/teacher.router");

const app = express();

app.use(express.json());

//router

//students
app.use("/students", studentRouter);

// teacher
app.use("/teacher", teacherRouter);

app.get("/", (req, res) => {
  res.send("this is home page");
});

app.get("/weather", (req, res) => {
  const data = {
    delhi: "Winter",
    chennai: "Summers",
    bangalore: "winter",
  };

  const { city } = req.query;

  const weather = data[city];

  res.send(`it is ${weather} in ${city}`);
});

app.listen("4676", () => {
  console.log("server is listening on 4676");
});
