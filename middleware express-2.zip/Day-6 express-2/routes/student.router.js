const express = require("express");

const studentRouter = express.Router();

studentRouter.get("/", (req, res) => {
  res.send("All students");
});

studentRouter.post("/addstudent", (req, res) => {
  console.log(req.body);
  res.send("Added the students");
});

studentRouter.get("/:id", (req, res) => {
  const id = req.params.id;
  res.send(`this is the data of a student with roll no ${id}`);
});

module.exports = {
  studentRouter,
};
