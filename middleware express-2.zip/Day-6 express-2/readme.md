### middleware

it refers to a function that executes during request and response.
it has access for request, response, next function in the application cycle.

how many types of middlewares?

- built-in -middleware ---> express.json(), express.router()
- custom middleware---> custom logic middleware.
- community middleware---> external

query and params

www.google.com?q=batman ----> filter large data.
weather.api.com?city=mumbai

/students/:roll_no --->unique data

Databases.

## what is a database?

client --- server----database

types of databases.

1. structured query language --->sql
2. Not a structured query language.-->Nosql ---> mongodb

-----------hero (Database)------

mongod --version

database---> collections---->documents ---{}

basic commands--CLI

show dbs---> show all the databases.
use "database_name"---> you can create a database with this

show collections---> it will show all the collections

db."collection_name".find()---> it will give all the documents inside that collection.

cls ----> to clear the shell.

db.createCollection("collection_name"); ---> use to create a collection

db."collection_name".insertOne({}) ---> to insert into the collection (1 document)

db."collection_name".insertMany({},{},{})
