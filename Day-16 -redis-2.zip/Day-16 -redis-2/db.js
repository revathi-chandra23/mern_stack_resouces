const mongoose = require("mongoose");

const connection = mongoose.connect("mongodb://127.0.0.1:27017/redis");

const goldschema = mongoose.Schema({
  name: { type: String, default: "Gold" },
  price: Number,
});

const GoldModel = mongoose.model("goldrate", goldschema);
module.exports = { GoldModel, connection };
