const express = require("express");
const Redis = require("ioredis");
const { GoldModel, connection } = require("./db.js");

const app = express();

app.use(express.json());

const redis = new Redis();

app.get("/", (req, res) => {
  res.send("welcome");
});

app.get("/goldrate", async (req, res) => {
  //get goldrate from db and send it
  //if redis has the data get it or else use db
  redis.get("goldratecache", async (err, result) => {
    if (err) {
      console.error(err);
    } else {
      if (result) {
        console.log("redis data", result);
        res.send({ goldrate: result });
      } else {
        let goldratefromdb = await GoldModel.findOne({ name: "Gold" });

        res.send({ goldrate: goldratefromdb.price });
      }
    }
  });
});

app.patch("/goldrate", async (req, res) => {
  const { gold_rate } = req.body;

  await GoldModel.updateOne(
    { name: "Gold" },
    { price: gold_rate },
    { upsert: true }
  );

  redis.set("goldratecache", gold_rate, "EX", 180);

  res.send("stored successfuly");
});

app.listen(8089, async (req, res) => {
  try {
    await connection;
  } catch {
    console.log("err connecting db");
  }
  console.log("listening on port 8089");
});
