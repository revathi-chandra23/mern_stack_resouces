// const winston = require("winston");

// const logger = winston.createLogger({
//   level: "debug",
//   format: winston.format.json(),
//   transports: [new winston.transports.Console()],
// });

const { createLogger, format, transports } = require("winston");
const { combine, timestamp, label, printf, prettyPrint } = format;

const CATEGORY = "winston custom format";

// using the printf format
const customFormat = printf(({ level, message, label, timestamp }) => {
  return `${timestamp} [${label}] ${level}: ${message}`;
});

const logger = createLogger({
  level: "debug",
  format: combine(
    label({ label: CATEGORY }),
    timestamp({
      format: "MMMM-DD-YYYY HH:mm:ss",
    }),
    prettyPrint()
  ),
  transports: [
    new transports.Console(),
    new transports.File({
      level: "error",
      filename: "logs/error.log",
    }),
    new transports.File({
      filename: "logs/example.log",
    }),
  ],
});

module.exports = logger;
