const express = require("express");
// const winston = require("winston");
// const expressWinston = require("express-winston");
const logger = require("./logger");
const app = express();

// app.use(
//   expressWinston.logger({
//     transports: [
//       new winston.transports.Console({
//         json: true,
//         colorize: true,
//         level: "warn",
//       }),

//       //transport to a file
//       new winston.transports.File({
//         level: "info",
//         filename: "infologs.log",
//       }),
//     ],
//   })
// );

app.get("/", (req, res, next) => {
  logger.log("debug", "hello, winston");
  logger.debug("this is home '/' route.");
  res.status(200).send("logging hello world");
});

app.get("/result", (req, res) => {
  res.status(404).send("not found");
});

app.get("/reports", (req, res) => {
  const token = req.query.token;
  if (token != 123) {
    res.status(401).send("unauthorized");
  } else {
    res.send("reports");
  }
});
app.get("/event", (req, res, next) => {
  try {
    throw new Error("not user!");
  } catch (error) {
    logger.error("event:error: unauthenticated user");
    res.status(500).send("error!");
  }
});

app.listen(6787, () => {
  console.log("listening on port 6878");
});
