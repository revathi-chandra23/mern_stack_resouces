### monitoring and logging

### logging

- refers to having an application which write a record of each event that occours to a file on disk.
- thse logs files can be read by administrator to analyze what the application was doing at a given point of time
- web servers typically log a record of each http request they handle, along with timestamp, the url and http method and the http response code.

## logging in code

- In node.js , we have logging package that allow you to add lines of text to a log file as the application running.

## key element in log statement.

- timestamp, log message , code file and line number.

Depending on what type of functionality the code is handling, it also useful to include some of the follwing:

1. the server name if more than one server is writing the log file.
2. url, http status code, incoming ip address
3. username: if the code is being executed in response to an action by a logged in user.
4. timing information
5. diagnostic information:
6. error message

## what events to log.

1. every http request and corresponding response, include url, http response code, time.
2. also log any significant action :

- input validation failures
- authentication success or failures.
- authorization failures.
- session management failure
- application errors and system event.
- startup and shutdown events
- user event like singup, password change, account deletions
- third part services or API
- legal and other opi-ins eg: when a users accepts the terms of use.

## what not to log

- user and system password
- encryption key
- database connection string
- api keys
- personal information of user
- payment information like credit card.
- http authorization headers.
- session cookies, session ID.
- tokens (signup token or password reset)
- information of user has opted out

## log levels

DEBUG
INFO
WARNING
ERROR

## log aggregation and storage

- logs should be centralized and stored securely so they can be viewed by administrators.
- logs servers like logstash, graylog, splunk and papertrail will aggregate log files from different sources and allow them to be searched and analyzed in real time.

####

Winston is one of the best and most widely used node js logging option, we are using it because it is very flexible and open source.
