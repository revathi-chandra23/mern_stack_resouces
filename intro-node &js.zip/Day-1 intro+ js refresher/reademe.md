### what is node js ?

- A javascript runtime environment.
- Node is created with javascript in it.
- with is node we will be building our server (logic)
- v8 chrome engine which is used to allow js run on any machine

---

- 1. ways to declare a variable in javascript?
- var, let const.

primitive data types ---> number, boolean, string,null(user define) , undefined (default)
non primitive data types ---> array, function , object

---

1. let & const.
2. arrow function
3. object,properties and method
4. arrays and array methods.
5. array, objects & reference types.
6. spread and rest operators.
7. destructing
8. async code and promises
9. template literals.
