function print() {
  console.log("hi this is general function");
}
// print();

//arrow function or anonymous arrow function
const print2 = () => {
  console.log("this is arrow function");
};

print2();

//anonymous function
const print3 = function () {
  console.log("this is anonymous function");
};
print3();

// const add = (a, b) => {
//   return a + b;
// };

const add = (a, b) => a + b;

console.log(add(1, 2)); //a=1, b=2;
