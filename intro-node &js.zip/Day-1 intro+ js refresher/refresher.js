let names = "flm"; //declaring a variable and assigning a value;

names = "mahesh"; //reassigning the value;

// console.log(names);

const age = 12;

// age = 34;
// console.log(age);

const hasHobbies = true;

let friend; // javascript gives a undefined value for it.
console.log(friend);

var name2 = "goku";
console.log(name2);
