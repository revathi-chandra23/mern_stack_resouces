let hobbies = ["sports", "cooking", "TRAVELING"];

// for (let hobby of hobbies) {
//   console.log(hobby);
// }

//map, filter, forEach, reduce, sort--->array

// Map,filter---> return a new Array

let newArray = hobbies.map((hobby) => {
  return "Hobby:" + hobby;
});
// console.log(hobbies);
// console.log(newArray);

let example = [1, 2, 3, 4, 5, 6];
let newFIltered = example.filter((element) => {
  return element % 2 == 0;
});
// console.log(example);
// console.log(newFIltered);

// forEach--->for loop

//sort-----> sort the original array and return it.

let numbers = [2334, 565, 456, 678, 23, 5, 9, 1, 0, -98];

numbers.sort((a, b) => {
  return b - a;
});

console.log(numbers);
