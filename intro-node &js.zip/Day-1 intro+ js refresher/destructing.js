let person = {
  name: "flm",
  age: 12,
  place: "hyd",
  phone: 1234,
  hobbies: ["sport", "tv"],
};
let { hobbies } = person;
// console.log(hobbies);
// console.log(name);
// console.log(age);
// console.log(phone);

let array = ["mahesh", 23, 50067, 135434];

// let [name, age, pin, phone] = array;
// console.log(name);
// console.log(age);
// console.log(phone);

let arr = [
  { name: "yash", age: 27 },
  { name: "mahesh", age: 30 },
];

let [yash, mahesh] = arr;
let { name, age } = yash;
console.log(name);
