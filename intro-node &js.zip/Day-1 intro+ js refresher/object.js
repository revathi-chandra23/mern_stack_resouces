const person = {
  name: "flm",
  age: 29,
  greet: function () {
    console.log("hi, I am " + this.name);
  },
};

console.log(person.age);
person.greet();
