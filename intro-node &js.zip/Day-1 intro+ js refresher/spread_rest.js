// spread operator ---copy

let array1 = [1, 2, 3];
let array2 = [4, 5, 7];

let array3 = [...array1, ...array2, 6778, 8989];
// console.log(array3);

let object1 = {
  name: "GOKU",
  age: 13,
};
let object2 = {
  place: "DB",
};

let object3 = {
  ...object1,
  ...object2,
  name: "flm",
};
// console.log(object1);
// console.log(object3);

// ----------------------------------------------------------------------
//rest operator

function print(...array) {
  console.log(array);
}

print(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
