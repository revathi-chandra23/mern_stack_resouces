//setTimeout , setInterval ---> browser

// setTimeout(() => {
//   console.log("timer is done");
// }, 3000);

const fetchData = () => {
  const promise = new Promise((resolve, reject) => {
    setTimeout(() => {
      //   resolve("done");
      reject("there is an error");
    }, 2000);
  });
  return promise;
};

fetchData()
  .then((success) => {
    console.log(success);
  })
  .catch((error) => {
    console.log("error:", error);
  });

const fetching = async () => {
  try {
    // let response= await
  } catch (error) {
    console.log(error);
  }
};

let name = "gohan";
let age = 29;

console.log(`my  name is ${name}, and my age is ${age}`);
//template literals;
