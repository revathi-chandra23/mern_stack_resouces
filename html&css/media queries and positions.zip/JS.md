HTML-> structure of layout.
CSS ---> styling.
JS---> functionality
