import React, { useEffect, useState } from "react";

const Notes = () => {
  const [notes, setNotes] = useState("");

  useEffect(() => {
    fetch("http://localhost:8980/notes", {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    })
      .then((res) => res.json())
      .then((res) => {
        console.log(res);
        setNotes(res);
      })
      .catch((err) => console.log(err));
  }, []);

  const deleteNote = (noteID) => {
    fetch(`http://localhost:8980/notes/delete/${noteID}`, {
      method: "DELETE",

      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    })
      .then((res) => res.json())
      .then((res) => console.log(res))
      .catch((error) => console.log(error));
  };
  return (
    <div>
      <h1>Notes</h1>
      {notes
        ? notes.map((element) => {
            return (
              <div key={element._id}>
                <h1>{element.title}</h1>
                <p>{element.body}</p>
                <button onClick={() => deleteNote(element._id)}>Delete</button>
                <hr />
              </div>
            );
          })
        : "No Noes are there"}
    </div>
  );
};

export default Notes;
