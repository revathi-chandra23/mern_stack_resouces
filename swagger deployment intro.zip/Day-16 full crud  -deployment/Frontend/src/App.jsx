import React from "react";
import Signup from "./components/Signup";
import Login from "./components/Login";
import { Route, Routes } from "react-router-dom";
import Notes from "./components/Notes";

const App = () => {
  return (
    <div>
      <h1>Notes application</h1>
      <Routes>
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/notes" element={<Notes />} />
        //new notes // update note
      </Routes>
    </div>
  );
};

export default App;
