### deployment

- to make sure the server is running automatically.
- to make sure the server is available to everyone for use.

-4g ram, 1000
festival--->10,000 --->upgrade -32gb (system)
1000---> after festival

aws, azure , google cloud---> data engineering, cloud engineering, data analysis

railway (issue paid), heroku (paid), cyclic (free), render (paid)

---

## api documentation

notes--> give an idea about how to use our API
what all end points are present
for authentication, authorization

which endpoint is protected and which is not.

two external package

1. swagger-jsdoc
2. swagger- ui express
