const regularexpression1 = /\$a/;
// const regularexpression2 = new RegExp(".");
const string = "/[a-zA-Z0-9._%+-]+@[a-zA-z0-9.-]+\\.[a-zA-z]{2,}/g";

//testing --> .test method true or false
const result = regularexpression1.test(string);
console.log(result);

//match ---> .match  method --> matched_value or null

const match = string.match(regularexpression1);
console.log(match);
