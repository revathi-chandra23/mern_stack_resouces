### Regular expressions

it is a sequence of characters that define a search pattern.

where are they used ?

1. programming languages.
2. goolge forms example.

some uses:

1. to check if a string matches the pattern.
2. to replace the matched pattern;
3. to extract parts of a string that match the pattern - filter.

regular expressions - Regex or regex

sytnax

1. literal syntax - /some pattern /
2. constructor - new RegExp("some pattern")

some basic characters thet form /build a pattern

"." any single character.

"+" - one or more repetitions of the preceding / beefore /previous character (in the pattern)

"\*" - zero or more repetitions of preceding character(in the pattern)
"^" - start of a line ( it is used to check if a string starts with a certain character)
"$" - end ( it is used to check if a string ends with a certain character)
"?" - it matches zero or one occurence of the pattern left to it

{} consider this code: {n,m}. this means at lease n, and at most m repetitions of pattern left to it.

[0-9],[a-e],[abc]--> matches extact content.

| --> it is used for alternation (or opreator)
() ---> it is used to group sub-pattern for (a|b|c)xz match any string that matches either a or b or c followed by xz

\\ --> it is used to escape various characters including all meta character

1. we should be familiar with what regexp is
2. basic character like ., \*, +, ^, $

.test - return true or false - regex.test(string)

.match - return null or matched value
-string.match(regex)
-mahesh.match(/a.+/)

g - global - finds all matches, not just one
i - case insensitive
