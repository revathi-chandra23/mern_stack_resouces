import React from "react";

import {
  FormControl,
  FormGroup,
  FormLabel,
  FormControlLabel,
  FormHelperText,
  Checkbox,
} from "@mui/material";

const App = () => {
  return (
    <FormControl error>
      <FormLabel> my form</FormLabel>
      <FormGroup>
        <FormControlLabel control={<Checkbox defaultChecked />} label="Label" />
        <FormControlLabel control={<Checkbox defaultChecked />} label="Label" />
        <FormControlLabel control={<Checkbox defaultChecked />} label="Label" />
        <FormControlLabel control={<Checkbox defaultChecked />} label="Label" />
        <FormControlLabel control={<Checkbox defaultChecked />} label="Label" />
      </FormGroup>
      <FormHelperText>please select any one</FormHelperText>
    </FormControl>
  );
};

export default App;
