steps for styling components

1. finding the component which we want to use
2. finding the DOM element which contains the style which want to customize
3. finding the class causing the specific style.
4. determine whether that class is on the component root element or nested sub-component.
   4.1. if the class is present inside sub component
   check if there's a shortcut with a component props prop or component prop /
   create a selector targeting that component's class and add styles there.

   4.2 if it is on the root element , then add styles directly in the sx props on that component

5. if it is a static class like disabled, checked, expanded then add that class ot the selector

6. make sure your selector follows that "&" rule
