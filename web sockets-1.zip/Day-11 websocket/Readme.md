## web sockets

# problem statement

let say you are working on an app, that show show the live order status on the frontend side

example: swiggy, zomato, blinkit, blue dart
any delivery app with order status.

assume that the api is ready for it and the API end point is /orderstatus

Each time the API is hit, it returns the current order status.

assume that following possible order status

1. orderplaced
2. arrived at restaurant.
3. disptached.
4. delivered

api request at different times and responses status different.

how will you handle it/ use the API in frontend to show th live order status ?

## polling mechanism

this polling uses a pull mechanism to that it ask the server for the data.

client ------------------------request/response------------------------- server

client <----------handshake connect---------> server

advantage of websocket

- it allows for two way communication.
- websockets allow you to send and receive data much faster then HTTP.
- compatibility (web, desktop, mobile)
