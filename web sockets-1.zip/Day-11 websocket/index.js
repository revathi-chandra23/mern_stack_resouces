const { WebSocketServer } = require("ws");
// const WebSocketServer = require("websocket").server;

const wss = new WebSocketServer({ port: 8500 });

wss.on("connection", () => {
  console.log("a new connection created");
});

wss.on("message", (message) => {
  console.log(`receive message${message}`);
  // changes
  wss.send("received message:", message);
});

wss.on("close", () => {
  console.log("client disconnected");
});

//frontend side

const socket = new WebSocket("ws://localhost:8500");
//create a connection

socket.onopen = () => {
  console.log("connected to server");

  socket.send("hello from the client");
};

socket.onmessage = (event) => {
  console.log(`received message:${event.data}`);
};

socket.onclose = () => {
  console.log("websocket connection closed");
};
