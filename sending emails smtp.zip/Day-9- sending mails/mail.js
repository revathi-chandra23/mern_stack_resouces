const sgMail = require("@sendgrid/mail");
require("dotenv").config();
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const message = {
  to: "kmaheshsg01@gmail.com",
  from: "flmtechteam.webdev@gmail.com", // Use the email address or domain you verified above
  subject: "Sending with Twilio SendGrid is Fun",
  text: "Hello everyone",
  html: "<strong>First mail in sendGrid</strong>",
};

sgMail
  .send(message)
  .then((result) => {
    console.log("successful");
    console.log(result);
  })
  .catch((err) => {
    console.log("error sending mail");
    console.log(err);
  });
