// subject, to email, from email,body.

const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  host: "smtp.gmail.com", // this is a fake smtp server
  port: 587,
  auth: {
    user: "kmaheshsg01@gmail.com",
    pass: "nwdx vnbu xfbg erqu",
  },
});

//
transporter
  .sendMail({
    to: "flmtechteam.webdev@gmail.com",
    from: "maheshshivagoud@gmail.com", //xyz@flm.com
    subject: "1st email from nodejs",
    text: "hey  it from node.js our first mail using fake smtp mail service",
    html: '<h2 href="http://youtube.com">youtube</h2>',
  })
  .then(() => {
    console.log("mail send successfully");
  })
  .catch((err) => {
    console.log("error", err);
  });
