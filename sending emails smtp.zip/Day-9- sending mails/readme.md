## sending email.

- Nodemailer

1. it is very simple to use
2. need to provide email configuration.
3. can use tempory smtp/email service provider.
4. good to send single emails.

- sendGrid

1. We get a API key to use it.
2. Helpful for bulk emails as well.
