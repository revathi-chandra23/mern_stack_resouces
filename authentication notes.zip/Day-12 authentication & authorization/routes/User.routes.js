const express = require("express");
const { UserModel } = require("../models/User.model");
const jwt = require("jsonwebtoken");

const userRouter = express.Router();

userRouter.post("/register", async (req, res) => {
  try {
    const user = new UserModel(req.body);
    await user.save();

    res.status(200).send({ msg: "user has been created" });
  } catch (error) {
    console.log(error);
    res.status(400).send({ error: error.message });
  }
});

userRouter.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await UserModel.findOne({ email, password: password });
    // find({$and:[{email:email},{password:password}]})
    console.log(user);
    if (user) {
      const token = jwt.sign({ course: "backend" }, "secret");
      res.status(200).send({ msg: "login successful", token: token });
    } else {
      res.status(200).send({ msg: "wrong credentials" });
    }
  } catch (error) {
    console.log(error);
    res.status(400).send({ error: error.message });
  }
});

module.exports = {
  userRouter,
};
