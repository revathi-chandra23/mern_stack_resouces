const express = require("express");
const { connection } = require("./config/db");
const { userRouter } = require("./routes/User.routes");
const jwt = require("jsonwebtoken");

const app = express();

app.use(express.json());

app.use("/", userRouter);

app.get("/movies", (req, res) => {
  const { token } = req.query;
  jwt.verify(token, "secret", (error, decoded) => {
    if (decoded) {
      console.log(decoded);
      res.status(200).send("movie data");
    } else {
      res.status(400).send({ error: error.message });
    }
  });
});

app.listen("8980", async () => {
  try {
    await connection;
    console.log("connected to database");
  } catch (error) {
    console.log(error);
  }
  console.log("running at 8980");
});
