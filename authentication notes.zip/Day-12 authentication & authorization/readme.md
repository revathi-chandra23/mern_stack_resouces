## what is authentication?

- authentication is a process of verifying a users identity.

ex- logging in with username and password, face id, fingerprint.

## what is authorization?

- it is determines what actions or resources a user is allowed to access after being authenticated.

ex- a user can access their profile but not another user's profile.

- admin can manage users, while regular users cannot.

- api key
- role -based access control
- OAuth - third party framework
- session based -
- jwt - json web token

----> headers -- what algorithm used (HS256)
----> payload -- information (id, role)
--->signature -- security key

login---> token -->authorization

- why
  stateless - the server does not need to store session data.
  secure - the signature ensure the token is not tampered.
  scalable - microservices / monolithic
  cross-domain - jwt work seamlessly with different front-end clients.
