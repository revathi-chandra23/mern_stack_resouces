const express = require("express");
const { Server } = require("socket.io");
const http = require("http");
const cors = require("cors");

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*", //allow all orgins
    methods: ["GET", "POST"],
  },
}); // we are integrating http with websocket.

app.get("/", (req, res) => {
  res.send("base end point");
});

app.listen(9898, () => {
  console.log("listening on port: 9898");
});

let count = 0;
io.on("connection", (socket) => {
  count++;
  io.emit("newuser", count);

  socket.on("message", (mahesh) => {
    socket.broadcast.emit("usermsg", mahesh);
  });

  socket.on("disconnect", () => {
    count--;
    io.emit("newuser", count);
  });
  socket.emit("xyz", "hello");
});
