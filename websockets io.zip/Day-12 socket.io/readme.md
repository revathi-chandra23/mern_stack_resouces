### Socket.io

it is a javascript library for real time web application.
it enables real time bi-directional communication between client and sever.

it has two parts

1.  client side library that run on the browser.
2.  server side library for node.js
    Both component have an identical API.

---

socket.emit---> sends to that particular client

socket.broadcast.emit --> want to send to everyone except that user.

io.emit ---> everyone.
