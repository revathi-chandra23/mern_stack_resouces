const express = require("express");
const { User } = require("./models/User.model");
const { connection } = require("./config/db");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { authMiddleware } = require("./middlewares/authMiddleware");
const { blacklist } = require("./blacklist");

require("dotenv").config(); // to inform node that the env should connected to .env

const app = express();

app.use(express.json());

app.post("/signup", async (req, res) => {
  try {
    const { email, password, role } = req.body;

    //check if hte user already exists
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: "User already exists" });
    }

    //create a new user
    const hash_password = bcrypt.hashSync(password, 8);
    const user = new User({ email, password: hash_password, role });
    await user.save();
    res.json({ message: "user created successfully" });
  } catch (error) {
    res.send("something went wrong");
  }
});

app.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;

    //find the user by username
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "Invalid username or password" });
    }

    //compare the password

    const isPasswordMatch = await bcrypt.compare(password, user.password);

    if (!isPasswordMatch) {
      return res.status(401).json({ message: "Invalid password" });
    }

    //create a JWT
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
      expiresIn: 60, //60 seconds
    }); //normal token

    const refreshtoken = jwt.sign(
      { userId: user._id },
      process.env.REFRESH_SECRET,
      {
        expiresIn: 240, //240 seconds
      }
    );

    res.json({ message: "Login successfull", token, refreshtoken });
  } catch (error) {
    res.send("something went wrong");
  }
});

app.get("/notes", authMiddleware, (req, res) => {
  res.send("notes....");
});

app.get("/logout", authMiddleware, (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];

  blacklist.push(token);
  res.send("logout successfull");
});

app.get("/getnewtoken", (req, res) => {
  const refreshtoken = req.headers.authorization?.split(" ")[1];

  const decoded = jwt.verify(refreshtoken, process.env.REFRESH_SECRET);
  if (decoded) {
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
      expiresIn: 60,
    });
    return res.send(token);
  } else {
    res.send("invalid refresh token, plz login again");
  }
});

app.listen(7678, async () => {
  try {
    await connection;
    console.log("connected to db successfull");
  } catch (error) {
    console.log("error connecting to db");
    console.log(error);
  }
  console.log("listening on port 7678");
});
