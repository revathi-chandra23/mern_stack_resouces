const jwt = require("jsonwebtoken");
require("dotenv").config();

const { User } = require("../models/User.model");

const { blacklist } = require("../blacklist");

const authMiddleware = async (req, res, next) => {
  try {
    const token = req.headers.authorization.split(" ")[1];
    if (blacklist.includes(token)) {
      return res.status(401).json({ message: "unauthorized" });
    }
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    const { userId } = decodedToken;

    //check if the user exists
    const user = await User.findByID(userId);
    if (!user) {
      return res.status(401).json({ message: "unauthorized" });
    }

    //attach the user to the request object.
    req.user = user;

    next();
  } catch (error) {
    console.log(error);
    return res
      .status(401)
      .json({ message: "unauthorized", err: error.message });
  }
};

module.exports = { authMiddleware };
