//

import { Autocomplete, TextField, Paper } from "@mui/material";
import React from "react";
import { useState } from "react";

const CustomPaper = (props) => {
  const { sx, ...otherProps } = props;
  return (
    <Paper
      {...otherProps}
      sx={{
        ...sx,
        bgcolor: "red",
        "& .MuiAutocomplete-option": {
          color: "white",
        },
      }}
    >
      {props.children}
    </Paper>
  );
};

const options = ["apple", "banana", "pear", "orange"];
const App = () => {
  const [value, setValue] = useState([]);
  return (
    <Autocomplete
      open
      multiple
      value={value}
      onChange={(event, newValue) => setValue(newValue)}
      options={options}
      sx={{ width: 300 }}
      renderInput={(params) => <TextField {...params} label="fruits" />}
      slotProps={{
        chip: {
          sx: {
            color: "red",
            fontSize: "1.5rem",
            backgroundColor: "green",
          },
        },
      }}
      slots={{
        paper: CustomPaper,
      }}
    />
  );
};

export default App;
