const mongoose = require("mongoose");

const heroSchema = mongoose.Schema(
  {
    name: { type: String, required: true },

    city: { type: String, required: true },
  },
  {
    versionKey: false,
  }
);

const heroModel = mongoose.model("hero", heroSchema);

module.exports = {
  heroSchema,
  heroModel,
};
