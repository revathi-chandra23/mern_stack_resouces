const express = require("express");

const { UserModel } = require("../../models/User.model");

const userRouter = express.Router();
//post users
userRouter.post("/createuser", async (req, res) => {
  const data = req.body;

  try {
    const user = new UserModel(req.body);

    await user.save();
    res.send("user has been created");
  } catch (error) {
    console.log(error);
  }
});

//get users
userRouter.get("/users", async (req, res) => {
  try {
    const users = await UserModel.find();
    // this simillar to db.collectionName.find()

    res.send(users);
  } catch (error) {
    console.log(error);
  }
});

//update
userRouter.patch("/editusers/:userID", async (req, res) => {
  const userID = req.params.userID;

  const payload = req.body;

  try {
    const query = await UserModel.findByIdAndUpdate({ _id: userID }, payload);
    res.send("user has been updated");
  } catch (error) {
    console.log(error);
    res.send("err:", "something went wrong");
  }
});

//delete
userRouter.delete("/removeuser/:userID", async (req, res) => {
  const userID = req.params.userID;
  console.log(userID);
  try {
    await UserModel.findByIdAndDelete({ _id: userID });
    res.send(`user with userID: ${userID} has been delete`);
  } catch (error) {
    console.log("error in deleting");
  }
});

module.exports = {
  userRouter,
};
