const express = require("express");

const { heroModel } = require("../../models/Hero.model");

const heroRouter = express.Router();

heroRouter.post("/createhero", async (req, res) => {
  const data = req.body;

  try {
    const user = new heroModel(req.body);

    await user.save();
    res.send("hero has been created");
  } catch (error) {
    console.log(error);
  }
});

module.exports = {
  heroRouter,
};
