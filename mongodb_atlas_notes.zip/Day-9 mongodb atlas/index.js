const express = require("express");
const { connection } = require("./database");
const { userRouter } = require("./routes/user/User.route");
const { heroRouter } = require("./routes/hero/Hero.routes");

const app = express();

app.use(express.json());

// home url
app.get("/", (req, res) => {
  res.send("welcome");
});

app.use("/users", userRouter);
app.use("/heroes", heroRouter);
//running serve + mongodb
app.listen("4676", async () => {
  try {
    await connection;
    console.log("connected to db");
  } catch (error) {
    console.log("connection to db failed");
    console.log(error);
  }
  console.log("running on server at 4676");
});
